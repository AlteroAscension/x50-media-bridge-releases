#!/system/bin/sh
ui_print "- Installing X50 Media Bridge"
ui_print "- LSPosed scopes: LunarisApp, NSMediaCenter and AppleCarPlay"
ui_print "- Open X50 Media Bridge to inspect arbitration and settings"
true
